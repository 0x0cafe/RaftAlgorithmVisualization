var id = 0
module.exports = function puid() {
    return '__puid__' + (id++)
};