module.exports = {
    primary: '#e74c3c',
    secondary: '#2ecc71',
    tertiary: '#3498db',
    quaternary: '#f1c40f',
    quinary: '#2c3e50',
    senary: '#9b59b6',
    eigen: '#cbcbcb',
    difference: '#cbcbcb',
    shy: 'rgba(0, 0, 0, 0.2)'
}