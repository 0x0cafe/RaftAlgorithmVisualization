define({
    "register": {
        "ENABLE_CAPTCHA": true
    },
    "max_post_edit_days": 7,
    "lounge": {
        "follow_channel_prompt_views": 1,
        "motd_admin_url": "https://blog.disqus.com/introducing-collapsed-replies?utm_source=motd_admin&amp;utm_medium=web",
        "tracking": {
            "iframe_limit": 4,
            "list": [{
                "url": "//referrer.disqus.com/juggler/stat.gif?event=data_tracker",
                "forced_forums": ["disqus"],
                "rate": 0,
                "type": "img"
            }]
        },
        "AMAZON_ENABLED_ALL": false,
        "motd_home_title": "Introducing Collapsed Replies! Learn more about this upcoming change \ud83d\udcc3",
        "motd_admin_title": "Introducing Collapsed Replies! Learn more about this upcoming change \ud83d\udcc3",
        "motd_home_url": "https://blog.disqus.com/introducing-collapsed-replies?utm_source=motd_home&amp;utm_medium=web",
        "REALTIME": {
            "BACKOFF_INTERVAL": 4,
            "MAX_HANDSHAKE_FAILS": 1,
            "XHR_ENABLED": false,
            "THREAD_STALE_DAYS": 1
        },
        "telemetry_sample_percent": 1,
        "switches": {
            "reactions": {
                "forum_percent": 100,
                "forum": ["nics-first-new-policy-forum", "valueinquirerdotnet", "inquirernetentertainment", "globalnation-inquirernet", "inquirerdotnet", "inq-newsinfo", "inquirernetbusiness", "inqbandera", "cebudailynewsinq", "inquireropinion", "inquirernettechnology", "inquirerlifestyle", "motioncarsinquirer", "inquirernetsports", "pba-inquirer", "disqus", "https-thegameisreal-blogspot-com"]
            },
            "new_analytics_tab": {
                "is_staff": true,
                "percent": 100,
                "forum": ["disqus", "elliott", "spoilertvhome", "androidpolice", "batmannewscom", "wobh", "stylingyou", "hyperallergic", "destructoid", "uscho", "willametteweek", "themanrepeller", "theatlantic", "tvinsider", "arlnow", "truthout", "mental-floss", "dennis-denofgeek", "dennis-theweek", "channel-trailercentral"]
            },
            "gdpr_tos": {
                "is_staff": true,
                "percent": 100
            },
            "removePrivacyPolicy": {
                "forum": ["cnet-1", "zdnet-1", "techrepublic-1", "sri-test-local", "sri-consensus", "sri-consensus-dap"]
            },
            "customInvoices": {
                "percent": 100
            },
            "customCommentCounts": {
                "nmax": 5,
                "the-spruce-eats": 3,
                "downdetector": 10,
                "newsmaxhealth": 5,
                "https-www-syndromemagazine-com": 5,
                "newsmaxworld": 5,
                "esta-fallando-ecuador": 35,
                "www-isaechia-it": 5,
                "istheservicedown": 35,
                "is-the-service-down-uk": 35,
                "www-nextquotidiano-it": 5,
                "nmmoney": 5,
                "techrepublic-1": 3,
                "esta-fallando-espana": 35,
                "themanrepeller": 10,
                "newsmaxtv": 5,
                "uscho": 10,
                "esta-fallando-colombia": 35,
                "is-the-service-down-france": 35,
                "is-the-service-down-australia": 35,
                "mantle-ref": 1,
                "qa-thespruce": 1,
                "trashitaliano-1": 5,
                "adsnativetest": 5,
                "http-ilsignordistruggere-com": 5,
                "disqus": 25,
                "sta-fallendo": 35,
                "slamonline": 5,
                "gibt-es-eine-storung": 35,
                "bitchyfblog": 5,
                "www-violetta-rocks": 5,
                "zdnet-1": 3,
                "the-spruce-staging": 1,
                "is-the-service-down-canada": 35,
                "esta-fallando-mexico": 35
            },
            "home_ads": {
                "channelDiscussions": true
            },
            "moderation_improvements_intercom": {
                "percent": 0
            },
            "registrationFlow": {
                "enableSignup": true
            },
            "login_prompt_more_posts": {},
            "before_comment_callback": {
                "forum": ["dsqwordpress", "chivefest", "chivery", "chivery-staging", "thechiverules-brigade", "thechivereviewserver2012", "thechiverules-throttle", "thechiverules", "thechiverules-staging", "thechiverules"]
            },
            "subscription_intercom": {
                "percent": 0
            },
            "moderation_improvements": {
                "is_staff": true,
                "percent": 100,
                "forum": ["cnbc", "fattoquotidiano", "rawstory", "gematsu", "willametteweek", "batmannewscom", "androidpolice", "wobh", "alternet", "channel-offtopic", "channel-discussdisqus", "channel-channelchat"]
            },
            "num_comments": {
                "devel-d12": 20
            },
            "aet_intercom": {
                "percent": 0
            },
            "enable_hotjar": {
                "percent": 10
            },
            "forumDeactivationHub": {
                "is_staff": true,
                "percent": 100
            },
            "boomtrain": {
                "percent": 100
            },
            "gif_picker_forum_settings": {
                "forum_percent": 100,
                "forum": ["taylans", "disqus-demo-basic", "disqus-demo-plus", "disqus-demo-pro"]
            },
            "toxicity_mod_fe": {
                "percent": 100
            },
            "dismissibleToS": {
                "percent": 0
            },
            "editExpireUI": {
                "percent": 100
            },
            "ads_optional": {
                "org_percent": 100
            },
            "home_admin_channel": {
                "slug": ["disqusfun"]
            },
            "analytics_intercom": {
                "percent": 0
            },
            "sso_less_branding": {
                "forum": ["techrepublic-1", "zdnet-1", "zd-review-migration-2", "zd-migration-3", "cnet-migration-2", "cnet-migration-roadshow-2", "cnet-migration-es-2", "tr-dev", "zd-dev", "zdnet-dev", "cnet-es", "cnet-roadshow", "cnet-1", "cbs-sports-prod", "cbs-sports-staging", "sri-consensus", "sri-test-local", "sri-consensus-dap"]
            },
            "text_editor_buttons": {
                "is_staff": true,
                "percent": 100,
                "forum": ["disqus-demo-basic", "disqus-demo-plus", "disqus-demo-pro"]
            },
            "reveal_show_video": {
                "username": ["Digikid13", "ProductNate", "mariopaganini", "kalail610", "nicoleallard"],
                "org_percent": 25,
                "percent": 100
            },
            "intercomEnabled": {
                "is_staff": true,
                "percent": 0
            },
            "reveal_new_ad_products": {
                "username": ["Digikid13", "ProductNate", "adamstober", "mariopaganini", "kalail610"]
            },
            "viglinkv2": {
                "percent": 100
            },
            "suggested_actions": {},
            "toxicity_mod": {
                "is_staff": false,
                "percent": 0
            },
            "launch_pro": true,
            "home_ads_prevented": {
                "forum": ["iphoneincanada", "thehill-v4", "nmax", "toofab", "channel-discussdisqus", "patdollardcom"]
            },
            "enable_segmentio": {
                "percent": 100
            },
            "moderationRules": {
                "is_staff": true,
                "forum": ["merimbulanewsonline-com-au", "thegatewaypundit", "torfashion", "japantimes", "wnd-news", "dailyadvertiser-com-au", "gothamist", "tvtech", "northerndailyleader-com-au", "cinemablend", "malonetelegram", "belloflostsouls", "zdnet-1", "nowinstock", "androidpolice", "thehill-v4", "cnsnews", "sltrib", "mrctvcomments", "pcmag", "theatlanticcities", "badassdigest", "abcnewsdotcom", "thechiverules", "thedailycaller", "wccftech", "rawstory", "cnet-1", "bitcoincom", "tsest", "downdetector", "breitbartproduction", "sofifa", "alternet", "wrestlinginc", "evilmilk"]
            },
            "subscriptionsRedesign": {
                "is_staff": true,
                "percent": 100
            },
            "admin_setting__disable_branding": {
                "percent": 100
            },
            "reveal_show_display": {
                "username": ["Digikid13", "ProductNate", "mariopaganini", "kalail610", "nicoleallard"],
                "org_percent": 25,
                "percent": 100
            }
        },
        "motd_marketing_url": "https://blog.disqus.com/introducing-collapsed-replies?utm_source=motd_marketing&amp;utm_medium=web",
        "viglink": {
            "version": "v2min"
        },
        "NET_MOD_LIST": ["ryanvalentin", "iamfrancisyo", "wedamija", "ryan04", "tonyhue", "DisqusSweeper", "TaltonFiggins", "saeedoday", "webrender"],
        "motd_marketing_title": "Introducing Collapsed Replies! Learn more about this upcoming change \ud83d\udcc3",
        "sentry_rate_limit": 500
    },
    "readonly": false,
    "mentions": {
        "MAX_PER_POST": 30
    },
    "timelines": {
        "BLACKLISTED_FORUMS": ["cnn", "squiddev-justforfun", "squiddev-todayilearned", "squiddev-ama", "squid", "squiddev", "squid-changemyview", "squiddev-changemyview", "squid-justforfun", "squid-todayilearned", "squid-ama"]
    }
})