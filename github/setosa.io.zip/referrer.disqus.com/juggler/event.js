(function() {
    return {
        resp: "OK"
    };
})();